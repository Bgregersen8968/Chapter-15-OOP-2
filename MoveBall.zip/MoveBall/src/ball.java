import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
 import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
 import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
public class ball extends Application {
@Override // Override the start method in the Application class
public void start(Stage primaryStage) {
Pane pane = new Pane();
Circle circle = new Circle(120 , 120 , 60);
circle.setStroke(Color.BLACK);
circle.setFill(Color.BLACK);
pane.getChildren().add(circle);
HBox hBox = new HBox();
hBox.setSpacing(10);
hBox.setAlignment(Pos.CENTER);
Button btLeft = new Button("Left");
Button btUp = new Button("Up");
Button btDown = new Button("Down");
Button btRight = new Button("Right");
hBox.getChildren().add(btLeft);
hBox.getChildren().add(btUp);
hBox.getChildren().add(btDown);
hBox.getChildren().add(btRight);
BorderPane borderPane = new BorderPane();
borderPane.setCenter(pane);
borderPane.setBottom(hBox);
BorderPane.setAlignment(hBox, Pos.CENTER);
// Create a scene and place it in the stage 
 Scene scene = new Scene(borderPane, 240, 240);
 primaryStage.setTitle("ControlCircle"); // Set the stage title
 primaryStage.setScene(scene); // Place the scene in the stage
primaryStage.show(); // Display the stage
int min = -180;
int max = 180;

 


btLeft.setOnAction(e->{
	circle.setCenterX(circle.getCenterX() - 10);
	if (circle.getCenterX() < 60) {
		circle.setCenterX(circle.getCenterX() + 10);
		
	}
	//System.out.println(circle.getCenterX());
});
btRight.setOnAction(e->{
	circle.setCenterX(circle.getCenterX() + 10);
	if (circle.getCenterX() > 180) {
		circle.setCenterX(circle.getCenterX() - 10);
	}
	//System.out.println(circle.getCenterX());
});
btUp.setOnAction(e->{
	circle.setCenterY(circle.getCenterY() - 10);
	if (circle.getCenterY() < 60) {
		circle.setCenterY(circle.getCenterY() + 10);
	}
		
	//System.out.println(circle.getCenterY());
});
btDown.setOnAction(e->{
	circle.setCenterY(circle.getCenterY() + 10);
	if (circle.getCenterY() > 180) {
		circle.setCenterY(circle.getCenterY() - 10);
	}
	//System.out.println(circle.getCenterY());
	
	});
}
public static void main(String[] args) {
    launch(args);
}
}


