package OctagonAnimation;

import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
 import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Polygon;
 import javafx.stage.Stage;
 import javafx.util.Duration;
 import javafx.collections.ObservableList;
 import javafx.animation.FadeTransition;

public class animation extends Application {
 @Override // Override the start method in the Application class 
 public void start(Stage primaryStage) {
 // Create a pane
 Pane pane = new Pane();
 //Color color = new Color(0.25, 0.14, 0.333, 0.51);

// Create a rectangle
Rectangle rectangle = new Rectangle (0, 0, 25, 50);
rectangle.setFill(Color.PURPLE);
//rectangle.setOpacity(.1);

// Create a polygon
Polygon MyPolygon = new Polygon();
//Pane.getChildren().add(MyPolygon);
MyPolygon.setFill(Color.WHITE);
MyPolygon.setStroke(Color.BLACK);
MyPolygon.setRotate(22.5);

ObservableList<Double> list = MyPolygon.getPoints();
final double Width = 375, Height = 375;
double centerX = Width / 2, centerY = Height / 2;
double radius = Math.min(Width, Height) * 0.4;

for (int i = 0; i < 8; i++) {
	list.add(centerX + radius * Math.cos(2 * i * Math.PI / 8));
	list.add(centerY - radius * Math.sin(2 * i * Math.PI / 8));
	
}
   // Add MyPolygon and rectangle to the pane
pane.getChildren().add(MyPolygon);
pane.getChildren().add(rectangle);

   // Apply a fade transition to rectangle
FadeTransition ft =
 new FadeTransition(Duration.millis(4000), rectangle);
ft.setFromValue(1.0);
ft.setToValue(0.1);
ft.setCycleCount(Timeline.INDEFINITE);
ft.setAutoReverse(true);
ft.play(); // Start animation
rectangle.setOnMousePressed(e -> ft.pause());
rectangle.setOnMouseReleased(e -> ft.play());

 // Create a path transition
 PathTransition pt = new PathTransition();
pt.setDuration(Duration.millis(4000));
 pt.setPath(MyPolygon);
pt.setNode(rectangle);
pt.setOrientation(
PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
pt.setCycleCount(Timeline.INDEFINITE);
pt.setAutoReverse(true);
 pt.play(); // Start animation

MyPolygon.setOnMousePressed(e -> pt.pause());
MyPolygon.setOnMouseReleased(e -> pt.play());


// Create a scene and place it in the stage
 Scene scene = new Scene(pane, 400, 400);
 primaryStage.setTitle("PathTransitionDemo"); // Set the stage title
 primaryStage.setScene(scene); // Place the scene in the stage
  primaryStage.show(); // Display the stage
 }
	public static void main(String[] args) {
		launch(args);
	}
 }
